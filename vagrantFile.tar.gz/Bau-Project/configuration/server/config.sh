#!/bin/bash

<<END
* This file will contain required configurations to setup the whole server...
END

SERVER='/.Setup-Project/server'
WEBSERVER='/.Setup-Project/webserver'

if [[ "$UID" -eq "0" ]];
then
	echo "[-] Installing dependencies"
	apt update -y && apt upgrade -y
	apt install -y whois apache2 python3-pip docker.io vim ssh net-tools gdb

	echo "[-] Setting SETUID capability for python3"
	PYTHON=$(ls -la /usr/bin/python3 | cut -d ">" -f 2 | cut -d " " -f 2)
	setcap "cap_setuid+ep" /usr/bin/$PYTHON
	
	echo -e "[-] Compiling PackageDownloader and giving Setuid -> /usr/bin/PackageDownloader"
	gcc $SERVER/PackageDownloader.c -o $SERVER/PackageDownloader
        cp $SERVER/PackageDownloader /usr/bin/
        chmod +s /usr/bin/PackageDownloader

	echo "[-] Creating a Crontab (tar *)"
	echo '* * * * * root /bin/tar cvf /var/backups/Backup.tar /var/www/html/*' >> /etc/crontab

	echo "[-] Creating Users and configuring them"
	# Below line will fix home folder creation issue..
	echo "CREATE_HOME yes" >> /etc/login.defs
	groupadd admin
	groupadd forensic_department
	groupadd developers
	useradd -d /home/mohammad -p `mkpasswd 'Mohammad_threats2022!'` mohammad -G admin -s /bin/bash -m
	useradd -d /home/moayad -p `mkpasswd 'Moayad_threats2022!'` moayad -G adm -s /bin/bash -m
	useradd -d /home/zeyad -p `mkpasswd 'Zeyad_threats2022!'` zeyad -G forensic_department -s /bin/bash -m
	useradd -d /home/omar -p `mkpasswd 'Omar_threats2022!'` omar -G forensic_department -s /bin/bash -m
	useradd -d /home/khaled -p `mkpasswd 'Khaled_threats2022!'` khaled -G developers -s /bin/bash -m
	useradd -d /home/baker -p `mkpasswd 'Baker_threats2022!'` baker -G developers -s /bin/bash -m
	useradd -d /home/nabil -p `mkpasswd 'Nabil_threats2022!'` nabil -G developers,docker -s /bin/bash -m
	#python3 $SERVER/create_users.py
	
	echo "[-] Changing Computer name to: BAU-Project"
	echo "BAU-Project" > /etc/hostname
	
	
else
	echo "[!] Root privileges required"
fi

